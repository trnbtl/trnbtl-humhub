<?php
return array (
  'Back to modules' => 'Tilbake til moduler',
  'Breaking News Configuration' => 'Innstillinger for siste nytt',
  'Note: You can use markdown syntax.' => 'Merk: Du kan bruker Markdown-syntaks.',
  'Save' => 'Lagre',
);
