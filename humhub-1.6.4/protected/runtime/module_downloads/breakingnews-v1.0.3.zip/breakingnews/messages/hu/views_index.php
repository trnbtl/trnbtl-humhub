<?php
return array (
  'Close' => 'Bezárás',
);
