<?php
return array (
  'Close' => 'Tutup',
);
