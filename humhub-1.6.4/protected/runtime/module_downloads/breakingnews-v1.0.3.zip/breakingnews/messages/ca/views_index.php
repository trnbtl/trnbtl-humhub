<?php
return array (
  'Close' => 'Tanca',
);
