<?php
return array (
  'Close' => 'Κλείσιμο',
);
