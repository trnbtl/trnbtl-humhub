<?php
return array (
  'Active' => 'Päällä',
  'Mark as unseen for all users' => 'Merkitse näyttettäväksi kaikille käyttäjille',
  'Message' => 'Viesti',
  'Title' => 'Otsikko',
);
