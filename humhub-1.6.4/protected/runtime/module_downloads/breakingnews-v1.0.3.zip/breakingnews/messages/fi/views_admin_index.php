<?php
return array (
  'Back to modules' => 'Takaisin',
  'Breaking News Configuration' => 'Uutisten hallinta',
  'Note: You can use markdown syntax.' => 'Huomautus: Voit käyttää markdown-syntaksia.',
  'Save' => 'Tallenna',
);
