<?php
return array (
  'Close' => 'Luk',
);
