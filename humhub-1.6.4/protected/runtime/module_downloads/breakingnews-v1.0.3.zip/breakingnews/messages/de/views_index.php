<?php
return array (
  'Close' => 'Schließen',
);
