<?php
return array (
  'Back to modules' => 'Tornar ta os modulos',
  'Breaking News Configuration' => 'Configuración de Breaking News',
  'Note: You can use markdown syntax.' => 'Nota: Puetz usar sintaxis markdown.',
  'Save' => 'Alzar',
);
