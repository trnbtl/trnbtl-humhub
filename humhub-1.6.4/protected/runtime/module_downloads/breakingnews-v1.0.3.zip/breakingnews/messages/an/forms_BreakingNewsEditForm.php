<?php
return array (
  'Active' => 'Activo',
  'Mark as unseen for all users' => 'Marcar como no visto pa totz os usuarios',
  'Message' => 'Mensache',
  'Title' => 'Títol',
);
