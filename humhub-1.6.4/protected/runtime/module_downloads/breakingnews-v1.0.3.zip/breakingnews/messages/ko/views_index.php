<?php
return array (
  'Close' => '닫기',
);
