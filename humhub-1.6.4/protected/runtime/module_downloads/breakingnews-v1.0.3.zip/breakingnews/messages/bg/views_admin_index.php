<?php
return array (
  'Back to modules' => 'Върни се при модулите',
  'Breaking News Configuration' => '',
  'Note: You can use markdown syntax.' => '',
  'Save' => 'Запази',
);
