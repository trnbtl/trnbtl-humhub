<?php
return array (
  'Close' => 'Đóng',
);
