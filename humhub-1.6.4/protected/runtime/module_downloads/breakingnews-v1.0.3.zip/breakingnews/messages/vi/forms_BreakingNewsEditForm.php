<?php
return array (
  'Active' => '',
  'Mark as unseen for all users' => '',
  'Message' => '',
  'Title' => 'Tiêu đề',
);
