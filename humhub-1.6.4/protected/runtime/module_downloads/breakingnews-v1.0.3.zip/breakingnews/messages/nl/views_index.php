<?php
return array (
  'Close' => 'Sluit',
);
