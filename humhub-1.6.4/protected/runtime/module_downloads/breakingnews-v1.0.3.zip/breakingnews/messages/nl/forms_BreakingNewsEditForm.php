<?php
return array (
  'Active' => 'Actief',
  'Mark as unseen for all users' => 'Markeren als ongelezen voor alle gebruikers',
  'Message' => 'Bericht',
  'Title' => 'Titel',
);
