<?php
return array (
  'Close' => 'Zamknij ',
);
