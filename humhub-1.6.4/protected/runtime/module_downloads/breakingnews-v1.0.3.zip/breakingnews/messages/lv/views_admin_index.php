<?php
return array (
  'Back to modules' => 'Atpakaļ uz moduļiem',
  'Breaking News Configuration' => 'Pēdējo jaunumu konfigurācija',
  'Note: You can use markdown syntax.' => 'Piezīme: Tu vari izmantot markdown sintaksi.',
  'Save' => 'Saglabāt',
);
