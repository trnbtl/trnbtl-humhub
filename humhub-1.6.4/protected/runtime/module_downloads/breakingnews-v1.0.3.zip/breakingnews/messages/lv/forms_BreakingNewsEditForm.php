<?php
return array (
  'Active' => 'Aktīvs',
  'Mark as unseen for all users' => 'Atzīmēt kā neizlasītu visiem lietotājiem',
  'Message' => 'Ziņa',
  'Title' => 'Nosaukums',
);
