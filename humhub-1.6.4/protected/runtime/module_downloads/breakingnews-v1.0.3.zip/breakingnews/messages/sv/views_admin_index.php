<?php
return array (
  'Back to modules' => 'Tillbaka till moduler',
  'Breaking News Configuration' => 'Senaste nytt inställningar',
  'Note: You can use markdown syntax.' => 'Not: du kan använda markdown syntax',
  'Save' => 'Spara',
);
