<?php
return array (
  'Active' => 'Actif',
  'Mark as unseen for all users' => 'Marquer comme "non lu" pour tous les utilisateurs',
  'Message' => 'Message',
  'Title' => 'Titre',
);
