<?php

return [
    'Close' => '',
];
