<?php
return array (
  'Back to modules' => 'Voltar para os módulos',
  'Breaking News Configuration' => 'Configurações de notícias de última hora',
  'Note: You can use markdown syntax.' => 'Nota: Você pode utilizar a sintaxe markdown.',
  'Save' => 'Guardar',
);
