<?php
return array (
  'Close' => 'Fechar',
);
