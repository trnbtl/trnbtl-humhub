<?php
return array (
  'Close' => 'Fèmen',
);
